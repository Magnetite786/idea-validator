import React from 'react';
import { Check } from 'lucide-react';

const tiers = [
  {
    name: 'Starter',
    id: 'tier-starter',
    price: '$29',
    description: 'Perfect for validating your initial idea.',
    features: [
      'Basic idea validation',
      'Market size calculator',
      'Competitive analysis',
      'Basic pitch deck generator',
      'Community access',
    ],
  },
  {
    name: 'Pro',
    id: 'tier-pro',
    price: '$99',
    description: 'Everything you need to launch your startup.',
    features: [
      'Advanced idea validation',
      'Full business model canvas',
      'Financial projections',
      'AI-powered pitch deck',
      'Mentor matching',
      'Investor database access',
      'Priority support',
    ],
  },
  {
    name: 'Enterprise',
    id: 'tier-enterprise',
    price: 'Custom',
    description: 'Custom solutions for accelerators and VC firms.',
    features: [
      'Custom AI models',
      'White-label solution',
      'API access',
      'Dedicated support',
      'Custom integrations',
      'Advanced analytics',
      'Multiple user seats',
    ],
  },
];

export default function Pricing() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl sm:text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Choose Your Launch Plan
          </h2>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Select the perfect plan for your startup journey. Scale as you grow.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl rounded-3xl ring-1 ring-gray-200 sm:mt-20 lg:mx-0 lg:flex lg:max-w-none">
          {tiers.map((tier) => (
            <div
              key={tier.id}
              className="p-8 sm:p-10 lg:flex-auto"
            >
              <h3 className="text-2xl font-bold tracking-tight text-gray-900">
                {tier.name}
              </h3>
              <p className="mt-6 text-base leading-7 text-gray-600">
                {tier.description}
              </p>
              <div className="mt-8 flex items-center gap-x-4">
                <h4 className="flex-none text-sm font-semibold leading-6 text-indigo-600">
                  What's included
                </h4>
                <div className="h-px flex-auto bg-gray-100" />
              </div>
              <ul
                role="list"
                className="mt-8 grid grid-cols-1 gap-4 text-sm leading-6 text-gray-600"
              >
                {tier.features.map((feature) => (
                  <li key={feature} className="flex gap-x-3">
                    <Check className="h-6 w-5 flex-none text-indigo-600" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}