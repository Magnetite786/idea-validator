import React from 'react';

const steps = [
  {
    id: '01',
    title: 'Submit Your Idea',
    description: 'Input your startup concept and let our AI analyze its potential.',
  },
  {
    id: '02',
    title: 'Receive Analysis',
    description: 'Get comprehensive market insights and validation within minutes.',
  },
  {
    id: '03',
    title: 'Develop Strategy',
    description: 'Use AI-generated recommendations to craft your business strategy.',
  },
  {
    id: '04',
    title: 'Launch & Scale',
    description: 'Access resources and support to bring your idea to market.',
  },
];

export default function HowItWorks() {
  return (
    <div className="bg-gray-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-base font-semibold leading-7 text-indigo-600">How It Works</h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            From Idea to Launch in Four Steps
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:max-w-none">
          <div className="grid grid-cols-1 gap-y-8 gap-x-6 lg:grid-cols-4">
            {steps.map((step) => (
              <div
                key={step.id}
                className="relative pl-16 lg:pl-0"
              >
                <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 lg:relative">
                  <span className="text-sm font-semibold text-white">{step.id}</span>
                </div>
                <div className="mt-4 lg:mt-6">
                  <h3 className="text-lg font-semibold leading-8 text-gray-900">
                    {step.title}
                  </h3>
                  <p className="mt-2 text-base leading-7 text-gray-600">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}