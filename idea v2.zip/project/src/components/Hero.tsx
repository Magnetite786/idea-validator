import React from 'react';
import { Rocket, ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-white">
      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="flex justify-center mb-8">
            <Rocket className="h-12 w-12 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
            LaunchLab AI
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Transform your startup idea into a market-ready business with AI-powered validation,
            planning, and guidance. Get instant feedback and actionable insights.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <a
              href="#idea-analyzer"
              className="rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Analyze Your Idea
            </a>
            <a href="#features" className="text-sm font-semibold leading-6 text-gray-900 flex items-center">
              Learn more <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}