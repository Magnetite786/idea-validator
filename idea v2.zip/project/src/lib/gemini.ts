import { GoogleGenerativeAI } from '@google/generative-ai';

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

if (!apiKey) {
  throw new Error('Invalid API key. Please check your GEMINI_API_KEY in .env file');
}

const genAI = new GoogleGenerativeAI(apiKey);

function validateStartupIdea(idea: string): string | null {
  if (!idea || idea.trim().length < 20) {
    return 'Please provide a more detailed description of your startup idea (minimum 20 characters).';
  }

  const commonGreetings = ['hi', 'hello', 'hey', 'test'];
  if (commonGreetings.includes(idea.toLowerCase().trim())) {
    return 'Please provide a real startup idea, not just a greeting.';
  }

  return null;
}

function formatResponse(text: string) {
  const defaultStructure = {
    marketPotential: '',
    uniqueValueProposition: '',
    targetAudience: '',
    challenges: [],
    suggestions: [],
    competitiveAnalysis: '',
    revenueStreams: [],
    nextSteps: []
  };

  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return { ...defaultStructure, ...parsed };
    }

    const sections = {
      marketPotential: text.match(/Market Potential:?(.*?)(?=Unique Value Proposition:|$)/s),
      uniqueValueProposition: text.match(/Unique Value Proposition:?(.*?)(?=Target Audience:|$)/s),
      targetAudience: text.match(/Target Audience:?(.*?)(?=Challenges:|$)/s),
      challenges: text.match(/Challenges:?(.*?)(?=Suggestions:|$)/s),
      suggestions: text.match(/Suggestions:?(.*?)(?=Competitive Analysis:|$)/s),
      competitiveAnalysis: text.match(/Competitive Analysis:?(.*?)(?=Revenue Streams:|$)/s),
      revenueStreams: text.match(/Revenue Streams:?(.*?)(?=Next Steps:|$)/s),
      nextSteps: text.match(/Next Steps:?(.*?)$/s)
    };

    const formatted = { ...defaultStructure };

    // Process each section
    Object.entries(sections).forEach(([key, match]) => {
      if (match?.[1]) {
        if (Array.isArray(formatted[key])) {
          formatted[key] = match[1]
            .split(/[\n•-]/)
            .map(item => item.trim())
            .filter(item => item.length > 0);
        } else {
          formatted[key] = match[1].trim();
        }
      }
    });

    return formatted;
  } catch (error) {
    console.error('Error formatting response:', error);
    throw new Error('Failed to format the analysis response');
  }
}

export async function analyzeStartupIdea(idea: string) {
  const validationError = validateStartupIdea(idea);
  if (validationError) {
    throw new Error(validationError);
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
    
    const prompt = `You are a startup advisor and business analyst. Analyze this startup idea and provide detailed, constructive feedback. If the idea seems incomplete or unclear, ask for clarification. Be specific and realistic in your analysis.

Market Potential:
[Provide a score out of 10 and detailed explanation of market size and potential. Be realistic and critical.]

Unique Value Proposition:
[Explain what makes this idea unique and valuable. If the idea lacks uniqueness, suggest ways to differentiate.]

Target Audience:
[Describe the primary and secondary target audiences. Be specific about demographics and needs.]

Challenges:
• [Challenge 1]
• [Challenge 2]
• [Challenge 3]
• [Challenge 4]
• [Challenge 5]

Suggestions:
• [Suggestion 1]
• [Suggestion 2]
• [Suggestion 3]
• [Suggestion 4]
• [Suggestion 5]

Competitive Analysis:
[Provide a detailed analysis of existing competitors and market dynamics.]

Revenue Streams:
• [Revenue Stream 1]
• [Revenue Stream 2]
• [Revenue Stream 3]
• [Revenue Stream 4]

Next Steps:
• [Step 1]
• [Step 2]
• [Step 3]
• [Step 4]

Startup Idea: "${idea}"

Important: If the idea is too vague or seems like a test/greeting, respond with a message asking for more details about the actual business concept.`;

    const result = await model.generateContent({
      contents: [{
        parts: [{ text: prompt }]
      }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 2048,
      }
    });

    const response = await result.response;
    const text = response.text();
    
    return formatResponse(text);
  } catch (error: any) {
    console.error('Error in API call:', error);
    throw new Error(`Failed to analyze startup idea: ${error.message}`);
  }
}