import OpenAI from 'openai';

const apiKey = import.meta.env.VITE_OPENAI_API_KEY;

if (!apiKey) {
  throw new Error('Invalid API key. Please check your API key in .env file');
}

// Initialize the OpenAI API client with browser support enabled
const openai = new OpenAI({
  apiKey: apiKey,
  dangerouslyAllowBrowser: true // Enable browser support
});

export async function analyzeStartupIdea(idea: string) {
  if (!idea.trim()) {
    throw new Error('Idea cannot be empty');
  }

  const prompt = `You are a startup advisor and business analyst. Analyze this startup idea and provide detailed feedback. Format your response EXACTLY as a JSON object with the following structure (maintain proper JSON format):

{
  "marketPotential": "Rate from 1-10 and explain why",
  "uniqueValueProposition": "What makes this idea stand out",
  "challenges": ["List 3-5 key challenges"],
  "suggestions": ["List 3-5 actionable suggestions"],
  "competitiveAnalysis": "Brief analysis of existing competitors",
  "revenueStreams": ["List 3-4 potential revenue streams"],
  "nextSteps": ["List 3-4 recommended next steps"]
}

Be concise but informative in your analysis. Ensure the response is valid JSON.

Startup Idea: ${idea}`;

  try {
    console.log('Making API request to OpenAI GPT-3.5-turbo...');
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
    });

    const text = response.choices[0].message?.content;
    const parsedResponse = JSON.parse(text || '{}');
    return parsedResponse;
  } catch (error: any) {
    console.error('Error in API call:', error.response ? error.response.data : error.message);
    throw new Error(`Failed to analyze startup idea: ${error.message}`);
  }
}