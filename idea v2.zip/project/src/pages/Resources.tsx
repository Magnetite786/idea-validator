import React from 'react';
import { BookOpen, FileText, Video, Download } from 'lucide-react';

const resources = [
  {
    title: 'Startup Validation Guide',
    description: 'Learn how to validate your startup idea with our comprehensive guide.',
    icon: BookOpen,
    link: '#',
    type: 'Guide',
  },
  {
    title: 'Market Analysis Templates',
    description: 'Download ready-to-use templates for conducting market analysis.',
    icon: FileText,
    link: '#',
    type: 'Template',
  },
  {
    title: 'Video Tutorials',
    description: 'Watch step-by-step tutorials on using LaunchLab AI effectively.',
    icon: Video,
    link: '#',
    type: 'Video',
  },
  {
    title: 'Resource Kit',
    description: 'Get our complete startup resource kit with tools and templates.',
    icon: Download,
    link: '#',
    type: 'Download',
  },
];

export default function Resources() {
  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
            Resources
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Access our comprehensive collection of startup resources, guides, and templates
            to help you build a successful business.
          </p>
        </div>

        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
          {resources.map((resource) => (
            <div
              key={resource.title}
              className="flex flex-col overflow-hidden rounded-2xl bg-white shadow-lg transition-all duration-200 hover:shadow-xl"
            >
              <div className="flex-1 p-6 sm:p-8">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-50">
                    <resource.icon className="h-6 w-6 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {resource.title}
                    </h3>
                    <p className="text-sm text-indigo-600">{resource.type}</p>
                  </div>
                </div>
                <p className="mt-4 text-gray-600">{resource.description}</p>
                <div className="mt-6">
                  <a
                    href={resource.link}
                    className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-500"
                  >
                    Access Resource
                    <svg
                      className="ml-1 h-4 w-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}