import React from 'react';
import { ArrowRight } from 'lucide-react';

const caseStudies = [
  {
    title: 'TechStart Innovation',
    category: 'SaaS',
    description: 'How TechStart used LaunchLab AI to validate their B2B SaaS platform and secure seed funding.',
    image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    link: '#',
  },
  {
    title: 'GreenTech Solutions',
    category: 'CleanTech',
    description: 'GreenTech leveraged our platform to analyze market potential for their sustainable energy solution.',
    image: 'https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    link: '#',
  },
  {
    title: 'HealthHub Connect',
    category: 'HealthTech',
    description: 'How HealthHub validated their telehealth platform and identified key market opportunities.',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    link: '#',
  },
];

export default function CaseStudies() {
  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
            Case Studies
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Discover how successful startups used LaunchLab AI to validate and launch their ideas.
          </p>
        </div>

        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-12 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {caseStudies.map((study) => (
            <article
              key={study.title}
              className="flex flex-col items-start bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-200 hover:shadow-xl"
            >
              <div className="w-full aspect-[16/9] relative overflow-hidden">
                <img
                  src={study.image}
                  alt={study.title}
                  className="absolute inset-0 h-full w-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-x-4 text-xs">
                  <span className="text-indigo-600 font-medium">{study.category}</span>
                </div>
                <div className="group relative">
                  <h3 className="mt-3 text-lg font-semibold leading-6 text-gray-900">
                    <a href={study.link}>
                      <span className="absolute inset-0" />
                      {study.title}
                    </a>
                  </h3>
                  <p className="mt-5 line-clamp-3 text-sm leading-6 text-gray-600">
                    {study.description}
                  </p>
                </div>
                <div className="mt-6">
                  <a
                    href={study.link}
                    className="flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-500"
                  >
                    Read Case Study
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}