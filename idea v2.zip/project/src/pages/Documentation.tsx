import React from 'react';
import { Book, Code, Shield, Zap } from 'lucide-react';

const sections = [
  {
    title: 'Getting Started',
    icon: Book,
    items: [
      { title: 'Introduction', href: '#' },
      { title: 'Quick Start Guide', href: '#' },
      { title: 'Basic Concepts', href: '#' },
    ],
  },
  {
    title: 'API Reference',
    icon: Code,
    items: [
      { title: 'Authentication', href: '#' },
      { title: 'Endpoints', href: '#' },
      { title: 'Rate Limits', href: '#' },
    ],
  },
  {
    title: 'Security',
    icon: Shield,
    items: [
      { title: 'Best Practices', href: '#' },
      { title: 'Data Protection', href: '#' },
      { title: 'Compliance', href: '#' },
    ],
  },
  {
    title: 'Advanced Features',
    icon: Zap,
    items: [
      { title: 'Custom Analysis', href: '#' },
      { title: 'Integrations', href: '#' },
      { title: 'Webhooks', href: '#' },
    ],
  },
];

export default function Documentation() {
  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
            Documentation
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Comprehensive guides and documentation to help you get the most out of LaunchLab AI.
          </p>
        </div>

        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-2">
            {sections.map((section) => (
              <div key={section.title} className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-xl font-semibold leading-7 text-gray-900">
                  <section.icon className="h-6 w-6 flex-none text-indigo-600" />
                  {section.title}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col">
                  <ul className="space-y-3">
                    {section.items.map((item) => (
                      <li key={item.title}>
                        <a
                          href={item.href}
                          className="text-base leading-7 text-gray-600 hover:text-indigo-600 transition-colors duration-200"
                        >
                          {item.title}
                        </a>
                      </li>
                    ))}
                  </ul>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}