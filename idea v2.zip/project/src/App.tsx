import React from 'react';
import { Toaster } from 'react-hot-toast';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import IdeaAnalyzer from './components/IdeaAnalyzer';
import Pricing from './components/Pricing';
import Footer from './components/Footer';
import Resources from './pages/Resources';
import Documentation from './pages/Documentation';
import CaseStudies from './pages/CaseStudies';
import Contact from './pages/Contact';

function HomePage() {
  return (
    <>
      <Hero />
      <IdeaAnalyzer />
      <Features />
      <HowItWorks />
      <Pricing />
    </>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
        <Toaster position="top-right" />
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/documentation" element={<Documentation />} />
          <Route path="/case-studies" element={<CaseStudies />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;