import { GoogleGenerativeAI } from '@google/generative-ai';

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

if (!apiKey) {
  throw new Error('Invalid API key. Please check your GEMINI_API_KEY in .env file');
}

// Initialize the API with the correct configuration
const genAI = new GoogleGenerativeAI(apiKey);

function formatResponse(text: string) {
  // Default structure for the analysis
  const defaultStructure = {
    marketPotential: '',
    uniqueValueProposition: '',
    challenges: [],
    suggestions: [],
    competitiveAnalysis: '',
    revenueStreams: [],
    nextSteps: []
  };

  try {
    // First attempt: Try direct JSON parsing
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return { ...defaultStructure, ...parsed };
    }

    // Second attempt: Parse the text response manually
    const sections = {
      marketPotential: text.match(/Market Potential:?(.*?)(?=Unique Value Proposition:|$)/s),
      uniqueValueProposition: text.match(/Unique Value Proposition:?(.*?)(?=Challenges:|$)/s),
      challenges: text.match(/Challenges:?(.*?)(?=Suggestions:|$)/s),
      suggestions: text.match(/Suggestions:?(.*?)(?=Competitive Analysis:|$)/s),
      competitiveAnalysis: text.match(/Competitive Analysis:?(.*?)(?=Revenue Streams:|$)/s),
      revenueStreams: text.match(/Revenue Streams:?(.*?)(?=Next Steps:|$)/s),
      nextSteps: text.match(/Next Steps:?(.*?)$/s)
    };

    const formatted = { ...defaultStructure };

    // Process each section
    if (sections.marketPotential?.[1]) {
      formatted.marketPotential = sections.marketPotential[1].trim();
    }
    if (sections.uniqueValueProposition?.[1]) {
      formatted.uniqueValueProposition = sections.uniqueValueProposition[1].trim();
    }
    if (sections.challenges?.[1]) {
      formatted.challenges = sections.challenges[1]
        .split(/[\n•-]/)
        .map(item => item.trim())
        .filter(item => item.length > 0);
    }
    if (sections.suggestions?.[1]) {
      formatted.suggestions = sections.suggestions[1]
        .split(/[\n•-]/)
        .map(item => item.trim())
        .filter(item => item.length > 0);
    }
    if (sections.competitiveAnalysis?.[1]) {
      formatted.competitiveAnalysis = sections.competitiveAnalysis[1].trim();
    }
    if (sections.revenueStreams?.[1]) {
      formatted.revenueStreams = sections.revenueStreams[1]
        .split(/[\n•-]/)
        .map(item => item.trim())
        .filter(item => item.length > 0);
    }
    if (sections.nextSteps?.[1]) {
      formatted.nextSteps = sections.nextSteps[1]
        .split(/[\n•-]/)
        .map(item => item.trim())
        .filter(item => item.length > 0);
    }

    return formatted;
  } catch (error) {
    console.error('Error formatting response:', error);
    throw new Error('Failed to format the analysis response');
  }
}

export async function analyzeStartupIdea(idea: string) {
  if (!idea.trim()) {
    throw new Error('Idea cannot be empty');
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
    
    const prompt = `Analyze this startup idea and provide a detailed analysis in the following format:

Market Potential:
[Provide a score out of 10 and detailed explanation of market size and potential]

Unique Value Proposition:
[Explain what makes this idea unique and valuable]

Challenges:
• [Challenge 1]
• [Challenge 2]
• [Challenge 3]

Suggestions:
• [Suggestion 1]
• [Suggestion 2]
• [Suggestion 3]

Competitive Analysis:
[Analyze the competitive landscape]

Revenue Streams:
• [Revenue Stream 1]
• [Revenue Stream 2]
• [Revenue Stream 3]

Next Steps:
• [Step 1]
• [Step 2]
• [Step 3]

Startup Idea: "${idea}"`;

    const result = await model.generateContent({
      contents: [{
        parts: [{ text: prompt }]
      }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024,
      }
    });

    const response = await result.response;
    const text = response.text();
    
    // Format the response into the required structure
    return formatResponse(text);
  } catch (error: any) {
    console.error('Error in API call:', error);
    throw new Error(`Failed to analyze startup idea: ${error.message}`);
  }
}