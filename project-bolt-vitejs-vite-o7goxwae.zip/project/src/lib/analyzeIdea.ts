import type { NextApiRequest, NextApiResponse } from 'next';
import OpenAI from 'openai';

const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
  throw new Error('OPENAI_API_KEY is not defined in your environment variables.');
}

// Initialize OpenAI API client
const openai = new OpenAI({
  apiKey,
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const { idea } = req.body;

    if (!idea || typeof idea !== 'string') {
      return res.status(400).json({ message: 'Invalid idea provided.' });
    }

    const prompt = `You are a startup advisor and business analyst. Analyze this startup idea and provide detailed feedback. Format your response EXACTLY as a JSON object with the following structure (maintain proper JSON format):

    {
      "marketPotential": "Rate from 1-10 and explain why",
      "uniqueValueProposition": "What makes this idea stand out",
      "challenges": ["List 3-5 key challenges"],
      "suggestions": ["List 3-5 actionable suggestions"],
      "competitiveAnalysis": "Brief analysis of existing competitors",
      "revenueStreams": ["List 3-4 potential revenue streams"],
      "nextSteps": ["List 3-4 recommended next steps"]
    }

    Startup Idea: ${idea}`;

    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
    });

    const text = response.choices[0].message?.content;
    const parsedResponse = JSON.parse(text || '{}');
    res.status(200).json(parsedResponse);
  } catch (error: any) {
    console.error('Error analyzing idea:', error.message);
    res.status(500).json({ message: `Failed to analyze idea: ${error.message}` });
  }
}
