import React from 'react';
import { Rocket } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 justify-between items-center">
          <div className="flex items-center">
            <Rocket className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">LaunchLab AI</span>
          </div>
          <div className="hidden sm:flex sm:items-center sm:space-x-8">
            <a href="#features" className="text-gray-500 hover:text-gray-900">Features</a>
            <a href="#how-it-works" className="text-gray-500 hover:text-gray-900">How It Works</a>
            <a href="#pricing" className="text-gray-500 hover:text-gray-900">Pricing</a>
            <button className="rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
              Get Started
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}