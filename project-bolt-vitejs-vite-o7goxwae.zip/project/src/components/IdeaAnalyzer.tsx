import React, { useState } from 'react';
import { 
  Loader2, 
  TrendingUp, 
  Lightbulb, 
  AlertTriangle, 
  ListChecks,
  Users, 
  Coins,
  ArrowRight,
  Star,
  Target
} from 'lucide-react';
import toast from 'react-hot-toast';
import { analyzeStartupIdea } from '../lib/gemini';

export default function IdeaAnalyzer() {
  const [idea, setIdea] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!idea.trim()) {
      toast.error('Please enter your startup idea');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const result = await analyzeStartupIdea(idea);
      setAnalysis(result);
      toast.success('Analysis complete!');
    } catch (error: any) {
      console.error('Analysis error:', error);
      setError(error.message);
      toast.error(error.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Function to render the market potential score with stars
  const renderMarketPotentialScore = (score: string) => {
    const numericScore = parseInt(score.split('/')[0]);
    return (
      <div className="flex items-center gap-1 mt-2">
        {[...Array(10)].map((_, index) => (
          <Star
            key={index}
            className={`h-5 w-5 ${
              index < numericScore ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div id="idea-analyzer" className="max-w-5xl mx-auto px-4 py-12">
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Startup Idea Analyzer</h2>
        <form onSubmit={handleAnalyze} className="space-y-6">
          <div>
            <label htmlFor="idea" className="block text-sm font-medium text-gray-700 mb-2">
              Describe your startup idea
            </label>
            <textarea
              id="idea"
              rows={4}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 resize-none"
              placeholder="Enter your innovative startup idea here..."
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
            />
          </div>
          <button
            type="submit"
            disabled={isAnalyzing}
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 transition-colors duration-200"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />
                Analyzing...
              </>
            ) : (
              <>
                <Target className="mr-2 h-5 w-5" />
                Analyze Idea
              </>
            )}
          </button>
        </form>
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg">
          <p className="font-medium flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            Error: {error}
          </p>
        </div>
      )}

      {analysis && (
        <div className="mt-8 space-y-8">
          <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <TrendingUp className="h-8 w-8 text-indigo-600" />
            Analysis Results
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Market Potential Card */}
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Market Potential</h3>
              </div>
              {renderMarketPotentialScore(analysis.marketPotential)}
              <p className="mt-4 text-gray-600">{analysis.marketPotential}</p>
            </div>

            {/* Unique Value Proposition Card */}
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Lightbulb className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Unique Value Proposition</h3>
              </div>
              <p className="text-gray-600">{analysis.uniqueValueProposition}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Challenges Card */}
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-orange-100 rounded-lg">
                  <AlertTriangle className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Key Challenges</h3>
              </div>
              <ul className="space-y-3">
                {analysis.challenges.map((challenge: string, index: number) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-full bg-orange-100 text-orange-600 text-sm">
                      {index + 1}
                    </span>
                    <span className="text-gray-600">{challenge}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Suggestions Card */}
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-green-100 rounded-lg">
                  <ListChecks className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Suggestions</h3>
              </div>
              <ul className="space-y-3">
                {analysis.suggestions.map((suggestion: string, index: number) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-full bg-green-100 text-green-600 text-sm">
                      {index + 1}
                    </span>
                    <span className="text-gray-600">{suggestion}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Competitive Analysis Card - Full Width */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Competitive Analysis</h3>
            </div>
            <p className="text-gray-600">{analysis.competitiveAnalysis}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Revenue Streams Card */}
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <Coins className="h-6 w-6 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Revenue Streams</h3>
              </div>
              <ul className="space-y-3">
                {analysis.revenueStreams.map((stream: string, index: number) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-full bg-yellow-100 text-yellow-600 text-sm">
                      {index + 1}
                    </span>
                    <span className="text-gray-600">{stream}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Next Steps Card */}
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <ArrowRight className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Next Steps</h3>
              </div>
              <ul className="space-y-3">
                {analysis.nextSteps.map((step: string, index: number) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-full bg-indigo-100 text-indigo-600 text-sm">
                      {index + 1}
                    </span>
                    <span className="text-gray-600">{step}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}